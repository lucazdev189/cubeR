# cubeR - the R package for speedcubing  
**This package scrapes data from the WCA website.**

## Installation  
```
library(devtools)
install_github("lucazdev189/cubeR")
```
